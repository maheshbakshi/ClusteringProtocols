#!/bin/bash
tar xvf ns-234-leach.tar*
cd ns-234-leach/
cp -r mit /root/ns-allinone-2.34/ns-2.34
cp apps/app.* /root/ns-allinone-2.34/ns-2.34/apps
cp mac/channel.cc /root/ns-allinone-2.34/ns-2.34/mac
cp mac/ll.h /root/ns-allinone-2.34/ns-2.34/mac
cp mac/wireless-phy.* /root/ns-allinone-2.34/ns-2.34/mac
cp mac/phy.* /root/ns-allinone-2.34/ns-2.34/mac
cp mac/mac.cc /root/ns-allinone-2.34/ns-2.34/mac
cp mac/mac-sensor* /root/ns-allinone-2.34/ns-2.34/mac
cp trace/cmu-trace.* /root/ns-allinone-2.34/ns-2.34/trace
cp common/packet.* /root/ns-allinone-2.34/ns-2.34/common
cp common/mobilenode.cc /root/ns-allinone-2.34/ns-2.34/common
cp tcl/mobility/leach-c.tcl /root/ns-allinone-2.34/ns-2.34/tcl/mobility
cp tcl/mobility/leach.tcl /root/ns-allinone-2.34/ns-2.34/tcl/mobility
cp tcl/mobility/mte.tcl /root/ns-allinone-2.34/ns-2.34/tcl/mobility
cp tcl/mobility/stat-clus.tcl /root/ns-allinone-2.34/ns-2.34/tcl/mobility
cp tcl/ex/wireless.tcl /root/ns-allinone-2.34/ns-2.34/tcl/ex
cp test /root/ns-allinone-2.34/ns-2.34
cp leach_test /root/ns-allinone-2.34/ns-2.34
cp Makefile /root/ns-allinone-2.34/ns-2.34
cp Makefile.in /root/ns-allinone-2.34/ns-2.34



